# react-baby-names

A ReactJS app to find inspiration for baby names. Built with the nifty [create-react-app](https://github.com/facebookincubator/create-react-app) package.

---
 Development: `npm start`

 Production build: `npm run build`
 
 Release Tooling Configs: `npm run eject` (**cannot** be undone)

 **App demo**: [https://react-baby-names.surge.sh](https://react-baby-names.surge.sh)