/**
 * Created by GJS on 2017/3/23.
 */

import SimpleDemo from './SimpleDemo'

export default SimpleDemo;