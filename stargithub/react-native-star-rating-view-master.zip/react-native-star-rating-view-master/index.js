
import StarRatingView from './StarRatingView';

export default StarRatingView;
