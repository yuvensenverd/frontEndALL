import React from 'react'


class NamesList extends React.Component{
    render(){
        const { data, filtertext, addFavourite }  = this.props; // const { data } = this.props; >> Untuk Oper dari Parent Ke Child
    
        const nameList = 
        data.filter(name=>{
            //remove name that do not match filtertext
            return name.name.toLowerCase().indexOf(filtertext.toLowerCase()) >= 0;
        })
        .map(name => {
          return (
            <li key={name.id} className={name.sex} onClick={() =>addFavourite(name.id)}>{name.name}</li>
          )
        })
    
      return (
        <div className="App">
            <p> Filtertext value is {this.props.filtertext}</p>
        <ul>
        {nameList}
        </ul>
          
        </div>
      );
    }
}

export default NamesList;