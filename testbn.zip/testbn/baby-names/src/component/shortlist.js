import React from 'react'

export default ({data, favourites, deleteFavourite}) => {
    const namesList = favourites.map(id => {
        const { name, sex }  = data[id]
        console.log(name)
        return (
            <li key={id} className={sex} onClick={() => deleteFavourite(id)} >{name}</li>
        )
    })
    return(
        <div>
            <h4>Click the name to shortlist it... </h4>
            <ul>{namesList}</ul>
        </div>
        
    )
}
