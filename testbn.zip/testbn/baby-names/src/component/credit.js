import React from 'react'

export default () => 
    <div className="credit"> 
        <p>
            Source of the name List
            { ' '}
            <a href="www.yahoo.com"> Here</a>
        </p>
    </div>
    

