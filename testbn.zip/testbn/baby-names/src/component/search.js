import React from 'react'


class Search extends React.Component{

    filterUpdate(){
        const val = this.myvalue.value
        this.props.filterUpdate(val)
    }
    render(){
        return(
            <header>
            <form>
                <input type="text" 
                ref={(value) => {this.myvalue = value}}
                placeholder="type filter here" 
                onChange={this.filterUpdate.bind(this)}>

                </input>
            </form>
            </header>
        )
    }
        
    
}
export default Search