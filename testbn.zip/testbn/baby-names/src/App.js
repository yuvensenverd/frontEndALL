import React from 'react';
import logo from './logo.svg';
import './App.css';
import NamesList from './component/nameslist'
import Credit from './component/credit';
import Search from './component/search';
import Shortlist from './component/shortlist'

class App extends React.Component {
  constructor(props){
    super(props)
    this.state = {
      filtertext : '',
      favourites : []
    }
  }

  filterUpdate(value){
    this.setState({
      filtertext : value
    })
  }
  addFavourite(id){
    const favlist = this.state.favourites.concat([id])
    this.setState({
      favourites : favlist
    })
  }
  // remove ID from the favourites array
  deleteFavourite(id) {
    const { favourites } = this.state
    const newList = [
      ...favourites.slice(0, id),
      ...favourites.slice(id + 1)
      ]
    this.setState({
      favourites: newList
    })
  }
  render(){
   return(
     <div>
       <Search
        filtertext={this.state.filtertext}
        filterUpdate={this.filterUpdate.bind(this)}
       />
       <main>
       <Shortlist
       favourites={this.state.favourites}
       data={this.props.data}
       deleteFavourite={this.deleteFavourite.bind(this)}
       />
       <NamesList data={this.props.data} 
       filtertext={this.state.filtertext}
       addFavourite={this.addFavourite.bind(this)}
       /> 
       {/* // ini cara pass value ke child TTTT */}
       <Credit/>
       </main>
     </div>
   )
}
}

export default App;
