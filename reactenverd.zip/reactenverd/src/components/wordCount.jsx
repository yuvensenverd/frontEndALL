import React from 'react'
import { Button, Form, FormGroup, Label, Input, FormText } from 'reactstrap';
import { connect } from 'react-redux'
import { CountWord } from './../redux/actions/wordAction'

class wordCount extends React.Component{
    state = {
      text : null,
      count : 0,
    }
    
    onChangeTextUpdate= () => {
        var textarea = this.refs.wctext.refs.wctextinner.value
        // textarea = textarea.replace(/\s\s+/g, ' ');
        textarea = textarea.split(" ").filter((val) => {
          return val !== ""
        })
        var words = textarea.length       

        this.props.CountWord(words)
        // LOKAL
        // this.setState({count : words})
        // var result = word.split(" ").length -1
        // this.props.Change(result)
        
    }

    render(){

        return(
      <div>
        <center>
        <h1>Ini Home </h1>
        <Input type="textarea" ref="wctext" innerRef="wctextinner" placeholder="Masukkan text" onChange={this.onChangeTextUpdate} />
        <br/>
        <div></div>
        </center>
        <center>
        <h1> Word Count </h1>
        {/* <h1>{this.state.count > 0 
          ? 
          this.state.count + " Words" 
          : 
          this.state.count > 5
          ?
          'Lebih dari Lima'
          :
          null}
          </h1> */}
          <h1>
            {this.props.words}
          </h1>
        </center>
      </div>
    
    )
        }
  }

const mapStateToProps = (state) => {
  return{
    words : state.word.words
    // words : > this.props words
    // word >> index.js >> word
    // words >> wordreducer, initialstate > word
  }
}

export default connect(mapStateToProps, {CountWord})(wordCount);