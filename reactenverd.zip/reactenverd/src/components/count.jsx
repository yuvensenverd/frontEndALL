import React from 'react'
import { connect } from 'react-redux'
import { Add, Min } from './../redux/actions/countAction'


class count extends React.Component{
    
    onBtnAddClick = () =>{
        this.props.Add()
    }
    onBtnRedClick = () =>{
        this.props.Min()
    }

    render(){
        console.log(this.props.count)
        return(
            
            <div className="container">
                <h1> Ini page Redux</h1>
                
            <div className = 'd-flex justify-content-center'>
            <input className="btn btn-outline-primary" type="button" value="-" onClick={this.onBtnRedClick}></input>
            <span className='ml-5 mr-5' style={{fontWeight : 'bolder', fontSize:'30px'}} >{this.props.count}</span>
            <input className="btn btn-outline-primary" type="button" value="+" onClick={this.onBtnAddClick}></input>
            
            </div>
            </div>
  
        )
    }
}

const mapStateToProps = (state) => {
    return{
        count : state.bebas.count
    }
}
export default connect(mapStateToProps, {Add, Min})(count);