import { type } from "os";
import React from 'react';
import ClassComp from './latihan';
//FUNCTIONAL COMPONENT

export function Button(){
    return(
        <input type='button' value="button"/>
        
    )
}

export function InputComp(){
    return(
        <input type='text' placeholder='text'></input>
    )
}



// EXPORT DEFAULT >> hanya bisa 1 kompoenne
// export default Button;

//EXPORT NAMED


//CLASS COMPONENT