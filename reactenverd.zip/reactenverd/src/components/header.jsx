import React from 'react';
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  NavLink,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem } from 'reactstrap';

import { Link } from 'react-router-dom'
import { connect } from 'react-redux'


class Header extends React.Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.state = {
      isOpen: false
    };
  }
  toggle() {
    this.setState({
      isOpen: !this.state.isOpen
    });
  }
  render() {
    return (
      <div>
        <Navbar color="light" light expand="md">
         <Link to="/" style={{color : 'black'}}> 
         <NavbarBrand >Home</NavbarBrand>
         </Link>
          <NavbarToggler onClick={this.toggle} />
          <Collapse isOpen={this.state.isOpen} navbar>
            <Nav className="ml-auto" navbar>
                <NavItem>
                    <NavLink> {this.props.count} </NavLink>
                </NavItem>
              <NavItem>
                <Link to="/todo" style={{textDecoration : 'none'}}>
                    <NavLink >Todos</NavLink>
                    </Link>
              </NavItem>
              
              <NavItem>
                <Link to='/components/apiWilayah' style={{textDecoration : 'none'}}>
                    <NavLink >apiWilayah</NavLink>
                    </Link>
              </NavItem>
              <NavItem>
                    <NavLink> {this.props.word} </NavLink>
                </NavItem>
              <NavItem>
                <Link to="/components/wordCount" style={{textDecoration : 'none'}}>
                    <NavLink >WordCount</NavLink>
                    </Link>
              </NavItem>
              <NavItem>
                  <Link to='/components/count'>
                <NavLink>Redux</NavLink>
                </Link>
              </NavItem>
              <UncontrolledDropdown nav inNavbar>
                <DropdownToggle nav caret>
                  Options
                </DropdownToggle>
                <DropdownMenu right>
                  <DropdownItem>
                    Option 1
                  </DropdownItem>
                  <DropdownItem>
                    Option 2
                  </DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem>
                    Reset
                  </DropdownItem>
                </DropdownMenu>
              </UncontrolledDropdown>
            </Nav>
          </Collapse>
        </Navbar>
      </div>
    );
  }
}
const mapStateToProps = (state) => {
    return {
        count : state.bebas.count,
        word : state.word.words
        
    }
}

export default connect(mapStateToProps) (Header);