import React from 'react'


// Lifecycle Method
// State Management
// Props

// PROPS Adalah Transfer data dari parent ke child

var nama = "fikri"

class Latihan extends React.Component{ // kalau mau mewarisi harus pakai class 
    render(){
        return(
            <div>
                {this.props.content} {nama}
            </div>
        )
    }
}

export default Latihan;