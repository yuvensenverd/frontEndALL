import React, { Component } from 'react'
import {Input} from 'reactstrap'
import Axios from 'axios'

const url = 'https://x.rajaapi.com/MeP7c5ne7UIqPcxXKljJgwrjH9lO5vRLXkFHNnksEUYO2mWtYZHlN8zRef/m/wilayah'

class Wilayah extends Component{
    state = {
        provinsi : [],
        kabupaten : [],
        loadingkabupaten : true,
        loadingprovinsi : true,
    
    }
    componentDidMount(){
        Axios.get(url+ '/provinsi')
        .then((res)=>{
            console.log(res.data.data)
            this.setState({provinsi : res.data.data})
        })
        .catch((err)=>{
            console.log(err)
        })


    }
    componentWillMount(){
        
    }
    printDataProvinsi = () => {
        var list = this.state.provinsi.map((val)=>{
            return (
                <option value={val.id}> {val.name} </option>
            )
        })
        
        return list 
    }
    printDataKabupaten = () => {
        var id = this.refs.provinsi.refs.innerprovinsi.value
        if(id !== "-1"){


        if(this.state.loadingprovinsi === false){

        
        
        Axios.get(url+"/kabupaten?idpropinsi="+id)
        .then((res) => {
            this.setState({kabupaten : res.data.data, loadingkabupaten: false})
            
        })
        .catch((err) => {
            console.log(err)
        })

    }else{
        
    }
}
}
    
    onChangeProv = () => {


        this.setState({loadingkabupaten : true, loadingprovinsi : false})
    }
    renderDataKabupaten = () => {
        if(this.state.loadingkabupaten === true){
            return(
                <option>Loading ...</option>
            )
        }
        
        
        var list = this.state.kabupaten.map((val) => {
            return (
                <option value={val.id} >{val.name}</option>
                
            )
            
        })
        
        
        return list
    
    }
    render(){
        if(this.state.provinsi.length === 0){
            return (
                <center>
                <h1>Loading .. . .. </h1>
                </center>
            )
        }
        
        return(
            <div className='container mt-5'>
                <center>
                <h1>API Wilayah Indonesia</h1>
                </center>
                <div className='row justify-content-center mt-5'>
                    <div className='col-md-4 '>
                        <Input ref='provinsi' onChange={this.onChangeProv} innerRef='innerprovinsi' className='border border-primary' type='select' >
                            <option value="-1" >Pilih Provinsi</option>
                            {this.printDataProvinsi()}
                           
                        </Input>
                    </div>
                    <div className='col-md-4' >
                        <Input className='border border-primary'  onClick={this.printDataKabupaten} type='select'>
                            <option>Pilih Kabupaten</option>
                            {this.renderDataKabupaten()}
                        </Input>
                    </div>
                </div>
            </div>
        )
    }
}

export default Wilayah;