import React from 'react'
import { Table } from 'reactstrap';


class Todo extends React.Component{
    constructor(props){
    super(props)
    this.state={
        data : [],
        selectedEdit : null
    }
}
    onBtnAddClick = () => {
        // Get Value
        // Put Value on State
        var todo = this.refs.useract.value
        var waktu = this.refs.userdate.value
        var validation = todo.replace(/\s/g, "")
        if(validation == "" || waktu == ""){
            window.alert("Lengkapi Inputan terlebih dahulu ")
        }else {

        
        var arr = []
        var obj = {
            todo, // Sama aja dgn todo : todo,
            waktu,
        }

        arr.push(obj)
        this.setState({
            data : this.state.data.concat(arr)
        })
        this.refs.useract.value = ""
        this.refs.userdate.value = ""
    }

    }
    onBtnDelClick= (index) => {
        var confirmation = window.confirm("apakah yakin untuk mendelete data? ")
        if(confirmation){
            var arr = this.state.data
            arr.splice(index , 1)
            this.setState({data : arr})
        }else {
            
        }
        
    }

    onBtnEditClick(index){
        console.log(index)
        this.setState({selectedEdit : index})
    }

    onBtnSaveClick(index){
        var confirmation = window.confirm("apakah yakin untuk mengubah data ? ")
        if(confirmation){
        var arr = this.state.data
        arr[index].todo = this.refs.todoedit.value
        arr[index].waktu = this.refs.waktuedit.value
        this.setState({data : arr, selectedEdit : null})}
        else { 

        }
    }


   

    printDataTodo = () => {
        var jsx = this.state.data.map((val, index) => {
            if(this.state.selectedEdit == index){
                return(
                    <tr>
                    <td>{index +1}</td>
                    <td><input type='text' ref="todoedit" className="form-control" defaultValue={val.todo}/> </td>
                    <td><input type='date' ref='waktuedit' className="form-control" defaultValue={val.waktu}/> </td>
                    <td> <input type='button' className='btn btn-success' value='Save' onClick={() =>this.onBtnSaveClick(index)}  /> </td>
                    {/* callback supaya tidak dijalankan sblm ditekan */}
                    <td> <input type='button' key={index} ref="userdelete" className='btn btn-info' value='Cancel' onClick={() =>this.setState({selectedEdit : null})} /> </td>                        
                </tr>
                )
            }
            else{
            return(
                <tr key={index}>
                <td>{index +1}</td>
                <td>{val.todo}</td>
                <td>{val.waktu}</td>
                <td> <input type='button' className='btn btn-primary' value='Edit' onClick={() =>this.onBtnEditClick(index)} /> </td>
                {/* callback supaya tidak dijalankan sblm ditekan */}
                <td> <input type='button'  ref="userdelete" className='btn btn-danger' value='Delete' onClick={() =>this.onBtnDelClick(index)} /> </td>                        
            </tr>
           
            )
            }
        }
        )
        return jsx
    }
    render(){
        return(
            <div>
                <h1> CRUD Toado App</h1>
                <Table>
                    <thead>
                        <tr>
                            <td>No</td>
                            <td>Todo</td>
                            <td>Waktu</td>
                            <td>Edit</td>
                            <td>Delete</td>
                        </tr>
                    </thead>
                    <tbody>
                            {this.printDataTodo()}
                        
                    </tbody>
                </Table>
                <div className='row'>
                    <div className='col-md-4'>
                        <input type="text" ref='useract' placeholder="masukkan Todo" className="form-control"/>
                    </div>
                    <div className='col-md-4'>
                        <input type="date" ref='userdate' placeholder="dd/mm/yyyy" className="form-control"/>
                    </div>
                    <div className='col-md-4'>
                        <input type="button" placeholder="masukkan Todo" className="form-control btn-success" value="Add" onClick={this.onBtnAddClick}/>
                    </div>

                </div>
            </div>
        )
    }
}

export default Todo;