export const CountWord = (length) => {
    return{
        type : 'COUNT_WORD',
        payload : length
    }
}