export const Add = () => {
    return {
        type : 'PLUS'
    }
}

export const Min = () => {
    return {
        type : 'MIN'
    }
}

