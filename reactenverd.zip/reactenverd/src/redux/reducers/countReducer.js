
// Count Reducer
const INITIAL_STATE = { 
    count : 0,
    words : 0
}

var CountReducer =  (state = INITIAL_STATE, action) => {
    if(action.type === 'PLUS'){
        return{...state, count: state.count +1} // kalau mau tambah variablle untuk diubah , sisa tambah koma di setelah +1
    }else if(action.type === 'MIN'){
        return{...state, count : state.count -1}
    }else if(action.type === "COUNT_WORD"){
        return{...state, words :  0}
    }else{
        return state
    }
} 

export default CountReducer;
//func diatas sama aaja dgn var CountReducer = (state.........)


