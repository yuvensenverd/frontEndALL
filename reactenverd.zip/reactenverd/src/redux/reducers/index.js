import CountReducer from './countReducer'
import { combineReducers } from 'redux'
import wordsReducer from './wordsReducer';

export default combineReducers({
    bebas : CountReducer,
    word : wordsReducer,
})