let no1 = [1, 2, 3];
let no2 = [no1, 4, 5, 6];
let no3 = [...no1, 7, 8, 9];
let no4 = [1,2,3,4,5,6,7,8,9,0]
console.log(no2);
// [[1, 2, 3], 4, 5, 6]
console.log(no3);
// [1, 2, 3, 7, 8, 9]
const newlist = [
    ...no4.slice(0, 2),
    ...no4.slice(2 + 1),
    ]
console.log(...no4.slice(0, 2))
console.log(...no4.slice(2 + 1))
    console.log(newlist)

    var w = [1,4,9,16,25]
    var x = w.map(Math.sqrt);
    var y = w.map((val)=> val * 2);
    var z = w.map((val)=> val!==9);
    console.log(x);
    console.log(y);
    console.log(z);