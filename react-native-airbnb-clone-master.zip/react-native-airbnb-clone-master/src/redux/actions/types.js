/**
 * Airbnb Clone App
 * @author: Andy
 * @Url: https://www.cubui.com
 */

// Navigation
export const LOG_IN = 'LOG_IN';
export const SET_LOGGED_IN_STATE = 'SET_LOGGED_IN_STATE';
