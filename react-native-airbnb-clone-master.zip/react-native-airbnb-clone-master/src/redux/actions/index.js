/**
 * Airbnb Clone App
 * @author: Andy
 * @Url: https://www.cubui.com
 */

import * as Navigation from './navigation';

const ActionCreators = Object.assign({},
  Navigation);

export default ActionCreators;
