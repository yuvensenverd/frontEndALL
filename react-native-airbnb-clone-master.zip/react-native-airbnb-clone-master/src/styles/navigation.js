/**
 * Airbnb Clone App
 * @author: Andy
 * @Url: https://www.cubui.com
 */

const transparentHeaderStyle = {
  borderBottomWidth: 0,
  elevation: 0,
};

export default transparentHeaderStyle;
